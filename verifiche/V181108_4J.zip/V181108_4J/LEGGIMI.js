// Rinomina questo file tuocognome.js (tutto in minuscolo)
// Al termine della verifica consegna solo questo file all'indirizzo disponibile su github.
// Inserisci solo il codice jquery necessario per risolvere gli esercizi rispettando il formato indicato nell'esempio sottostante
// Inviare gli esercizi con il formato indicato vale un punto nella correzione della verifica
// Invia solo il codice inserito dentro la funzione invocata al caricamento del documento
// Ad esempio se per risolvere l'esercizio uso il seguente codice:
$(document).ready(function(){
	$("p").click(function() { 	//codice da consegnare 
		$("p").hide();			//codice da consegnare 
	});							//codice da consegnare 
});

// Codice da Inviare

//ESERCIZIO 0
$("p").click(function() {
  $("p").hide();
});

//ESERCIZIO 1
...

//ESERCIZIO 2
...